import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contexts/authContexts";
import { Card, CardContent, CardHeader, CardTitle } from "../ui/card";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Textarea } from "../ui/textarea";

import { Calendar } from "../ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "../ui/popover";
import { Calendar as CalendarIcon } from "lucide-react";


const API_BASE_URL = "http://localhost:5000";

const AlcoholProfileForm = () => {
  const navigate = useNavigate();
  const { currentUser } = useAuth();
const [pickedDate, setPickedDate] = useState(null);

const formatYMD = (d) => {
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};


  const [form, setForm] = useState({
    why: "",
    positives: "",
    who: "",
    startDate:"",
    targetDays: ""
  });

  const handleChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!currentUser?.uid) {
      alert("You must be logged in.");
      return;
    }

    const payload = {
      userId: currentUser.uid,
      why: form.why,
      positives: form.positives,
      who: form.who,
      targetDays: Number.parseInt(form.targetDays, 10) || 0,
     startDate: form.startDate
    };

    try {
      const res = await fetch(`${API_BASE_URL}/alcohol/profile`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        navigate("/alcohol"); // back to landing which now shows progress
      } else {
        const txt = await res.text();
        alert(`Failed to save profile: ${res.status} ${txt}`);
      }
    } catch (err) {
      console.error(err);
      alert("Network error saving profile");
    }
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-muted px-4">
      <Card className="w-full max-w-xl shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-bold text-center">
            You're taking a powerful first step 💪
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block font-semibold mb-1">Why are you doing this?</label>
              <Textarea
                value={form.why}
                onChange={(e) => handleChange("why", e.target.value)}
                placeholder="Your motivation..."
                required
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">What are the positives of doing this?</label>
              <Textarea
                value={form.positives}
                onChange={(e) => handleChange("positives", e.target.value)}
                placeholder="Better health, more energy, etc..."
                required
              />
            </div>
            <div>
              <label className="block font-semibold mb-1">Who are you doing this for?</label>
              <Input
                value={form.who}
                onChange={(e) => handleChange("who", e.target.value)}
                placeholder="Myself, family, etc..."
                required
              />
            </div>

             <div>
  <label className="block font-semibold mb-1">Start date</label>

  <Popover>
    <PopoverTrigger asChild>
      <Button
        type="button"
        variant="outline"
        className="w-full justify-start text-left font-normal"
      >
        {pickedDate
          ? pickedDate.toLocaleDateString()
          : "Pick a date"}
        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
      </Button>
    </PopoverTrigger>
    <PopoverContent className="w-auto p-0" align="start">
      <Calendar
        mode="single"
        selected={pickedDate}
        onSelect={(date) => {
          setPickedDate(date);
          // keep your existing setForm helper:
          handleChange("startDate", date ? formatYMD(date) : "");
        }}
        initialFocus
        // Optional: disallow future dates
        disabled={(date) => date > new Date()}
      />
    </PopoverContent>
  </Popover>

  {/* Hidden input so your existing submit code sees startDate */}
  <input type="hidden" name="startDate" value={form.startDate} />
  <p className="text-xs text-muted-foreground mt-1">
    Pick the day you started your streak.
  </p>
</div>        

            <div>
              <label className="block font-semibold mb-1">Target number of days</label>
              <Input
                type="number"
                value={form.targetDays}
                onChange={(e) => handleChange("targetDays", e.target.value)}
                min={1}
                placeholder="E.g. 30"
                required
              />
            </div>

            <div className="text-center">
              <Button type="submit" className="mt-4 w-full">Save My Profile</Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default AlcoholProfileForm;
